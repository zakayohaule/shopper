package tz.go.ega.apiauthorizationserver.token;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class ApiAuthServerServiceImpl implements ApiAuthServerService {
    
    @Value("${api-auth-server.client-id}")
    private String clientId;

    @Value("${api-auth-server.client-secret}")
    private String clientSecret;

    @Value("${api-auth-server.token-endpoint}")
    private String tokenEndpoint;

    @Value("${api-auth-server.authorize-client-endpoint}")
    private String authorizeClientEndpoint;
    
    @Autowired
    ApiAuthServerRepository authServerRepository;
    
    @Override
    public String GetAccessToken() {
        ApiAuthServerToken token = GetAccessTokenFromDb();
        if (token != null)
        {
            if (!hasExpired(token.getExpiresAt())){
                return token.getAccessToken();
            }
        }
        TokenResponse tokenResponse = GetAccessTokenFromServer();
        return tokenResponse.getAccessToken();
    }

    @Override
    public ApiAuthResponse AuthorizeClient(HttpServletRequest request, String endpointName) {
        
        String clientToken = extractAccessTokenFromAuthorizationHeader(request);
        
        String accessToken = GetAccessToken();
        
        try {
            CloseableHttpClient client = HttpClients.createDefault();
            HttpGet clientAuthorizationRequest = new HttpGet(authorizeClientEndpoint + "?client_token=" + clientToken + "&endpoint_name=" + endpointName);
            System.out.println(clientAuthorizationRequest.getURI().toString());
            clientAuthorizationRequest.addHeader("Authorization", "Bearer "+accessToken);
            HttpResponse response = client.execute(clientAuthorizationRequest);
            String responseToString = EntityUtils.toString(response.getEntity());
            System.out.println(responseToString);
            return new ObjectMapper().readValue(responseToString, ApiAuthResponse.class);
        } catch (Exception e){
            e.printStackTrace();
        }
        return new ApiAuthResponse();
    }
    
    private String extractAccessTokenFromAuthorizationHeader(HttpServletRequest request)
    {
        //Removes the "Bearer " string from the authorization header
        return request.getHeader("Authorization").substring(7);
    }

    private TokenResponse GetAccessTokenFromServer() {
        try {
            CloseableHttpClient client = HttpClients.createDefault();
            HttpPost tokenRequest = new HttpPost(tokenEndpoint);
            List<NameValuePair> params = new ArrayList<>();
            params.add(new BasicNameValuePair("client_id", clientId));
            params.add(new BasicNameValuePair("client_secret", clientSecret));
            params.add(new BasicNameValuePair("grant_type", "client_credentials"));
            tokenRequest.setEntity(new UrlEncodedFormEntity(params));
            HttpResponse response = client.execute(tokenRequest);
            System.out.println("Requested token from api authorization server");
            String tokenResponseString = EntityUtils.toString(response.getEntity());
            TokenResponse tokenResponse =  new ObjectMapper().readValue(tokenResponseString, TokenResponse.class);
            client.close();
            SaveAccessToken(tokenResponse);
            return tokenResponse;
        } catch(Exception e) {
            e.printStackTrace();
        }
        return new TokenResponse();
    }

    private void SaveAccessToken(TokenResponse tokenResponse) {
        ApiAuthServerToken newToken = new ApiAuthServerToken();
        newToken.setAccessToken(tokenResponse.getAccessToken());
        
        DecodedJWT decodedJWT = JWT.decode(tokenResponse.getAccessToken());
        newToken.setExpiresAt(decodedJWT.getExpiresAt());
        
        ApiAuthServerToken current = authServerRepository.findFirstByOrderByExpiresAtDesc();
        if (current == null ){
            authServerRepository.save(newToken);
        }else {
            current.setAccessToken(newToken.getAccessToken());
            current.setExpiresAt(newToken.getExpiresAt());
            authServerRepository.save(current);
        }
    }

    private ApiAuthServerToken GetAccessTokenFromDb() {
        return authServerRepository.findFirstByOrderByExpiresAtDesc();
    }
    
    private Boolean hasExpired(Date date)
    {
        return date.before(new Date());
    }
}
