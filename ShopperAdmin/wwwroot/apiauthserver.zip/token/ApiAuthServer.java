package tz.go.ega.apiauthorizationserver.token;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

public class ApiAuthServer {
    @Autowired
    ApiAuthServerRepository authServerRepository;
   
    public static TokenResponse GetAccessTokenFromServer()
    {        
        try {
            CloseableHttpClient client = HttpClients.createDefault();
            HttpPost tokenRequest = new HttpPost("http://localhost:5000/connect/token");
            List<NameValuePair> params = new ArrayList<>();
            params.add(new BasicNameValuePair("client_id", "d3223047-6abd-4734-91f3-df4216f5792d"));
            params.add(new BasicNameValuePair("client_secret", "475a88e6-a689-4489-93f8-a5357414b529"));
            params.add(new BasicNameValuePair("grant_type", "client_credentials"));
            tokenRequest.setEntity(new UrlEncodedFormEntity(params));
            HttpResponse response = client.execute(tokenRequest);
            System.out.println("Requested token from api authorization server");
            String tokenResponseString = EntityUtils.toString(response.getEntity());
            System.out.println(tokenResponseString);
            TokenResponse tokenResponse =  new ObjectMapper().readValue(tokenResponseString, TokenResponse.class);
            System.out.println(tokenResponse);
            client.close();
            
            return tokenResponse;
        } catch(Exception e) {
            e.printStackTrace();
        }

        return new TokenResponse();
    } 
}
