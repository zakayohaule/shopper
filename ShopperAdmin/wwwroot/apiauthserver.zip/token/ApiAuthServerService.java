package tz.go.ega.apiauthorizationserver.token;

import javax.servlet.http.HttpServletRequest;

public interface ApiAuthServerService {
    String GetAccessToken();
    ApiAuthResponse AuthorizeClient(HttpServletRequest request, String endpointName);
}
