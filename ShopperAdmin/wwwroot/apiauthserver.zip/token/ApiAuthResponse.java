package tz.go.ega.apiauthorizationserver.token;

public class ApiAuthResponse {
    private Boolean success = false;
    private Boolean valid = false;
    private Boolean authorized = false;
    private String error = "Something went wrong";

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public Boolean getValid() {
        return valid;
    }

    public void setValid(Boolean valid) {
        this.valid = valid;
    }

    public Boolean getAuthorized() {
        return authorized;
    }

    public void setAuthorized(Boolean authorized) {
        this.authorized = authorized;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
    
    public Boolean isAuthorized(){
        return this.getSuccess() && this.getValid() && this.getAuthorized();
    }
    
    public Boolean invalidToken(){
        return this.getSuccess() && !this.getValid();
    }
}
