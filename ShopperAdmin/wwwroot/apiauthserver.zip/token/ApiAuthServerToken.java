package tz.go.ega.apiauthorizationserver.token;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;

@Entity(name = "api_auth_server_tokens")
public class ApiAuthServerToken {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Short Id;
    
    @Basic(optional = false)
    @Column(name="access_token", columnDefinition = "TEXT")
    private String accessToken;
    
    @Basic(optional = false)
    @Column(name="expires_at")
    private Date expiresAt;

    public Short getId() {
        return Id;
    }

    public void setId(Short id) {
        Id = id;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public Date getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(Date expiresAt) {
        this.expiresAt = expiresAt;
    }
}
